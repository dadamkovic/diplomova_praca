def power(x):
	return x ** 2
